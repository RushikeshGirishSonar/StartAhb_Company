import { Routes } from '@angular/router';
import { Login } from './auth/login/login';
import { OrderList } from './orders/order-list/order-list';
import { OrderForm } from './orders/order-form/order-form';
import { authGuard } from './auth/auth-guard';

export const routes: Routes = [
  { 
    path: 'login', 
    component: Login 
},

  {
    path: 'orders',
    component: OrderList,
    canActivate: [authGuard]
  },

  {
    path: 'orders/new',
    component: OrderForm,
    canActivate: [authGuard]
  },

  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' }
];
