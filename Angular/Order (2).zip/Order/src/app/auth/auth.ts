import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_BASE } from '../core/api.constants';

@Injectable({
  providedIn: 'root',
})
export class Auth {
  
  constructor(private http: HttpClient) { }

  login(data: any) {
    return this.http.post(`${API_BASE}/login`, data);
  }

  saveToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('token');
    }
    return null;
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  logout(){
    localStorage.clear();
  }
}
