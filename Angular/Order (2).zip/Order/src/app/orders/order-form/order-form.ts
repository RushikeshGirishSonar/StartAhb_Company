import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { OrderService } from '../order.service';
import { Order, OrderStatus } from '../order.model';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './order-form.html',
  styleUrl: './order-form.css',
})
export class OrderForm {

  order: Order = {
    customerName: '',
    productName: '',
    quantity: 1,
    price: 0,
    deliveryAddress: '',
    status: OrderStatus.PLACED
  };

  // Used for dropdown
  orderStatuses = Object.values(OrderStatus);

  constructor(
    private orderService: OrderService,
    private router: Router
  ) {}

  saveOrder(): void {
    console.log('Sending order:', this.order);

    this.orderService.create(this.order).subscribe({
      next: () => {
        alert('Order created successfully');
        this.router.navigate(['/orders']);
      },
      error: (err) => {
        console.error('Backend error:', err);
        alert('Failed to create order');
      }
    });
  }
}
