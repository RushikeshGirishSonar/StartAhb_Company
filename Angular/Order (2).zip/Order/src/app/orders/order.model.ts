export interface Order {
  id?: number;

  customerName: string;
  productName: string;
  quantity: number;
  price: number;
  deliveryAddress: string;

  // MUST match backend enum
  status: OrderStatus;
}

// Enum mirror of backend enum
export enum OrderStatus {
  PLACED = 'PLACED',
  SHIPPED = 'SHIPPED',
  DELIVERED = 'DELIVERED',
  CANCELLED = 'CANCELLED'
}
