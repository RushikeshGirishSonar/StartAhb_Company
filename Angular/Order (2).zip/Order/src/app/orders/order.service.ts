import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_BASE } from '../core/api.constants';
import { Order } from './order.model';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  
  constructor(private http: HttpClient) { }

  getAll(){
    return this.http.get<Order[]>(`${API_BASE}/api/orders`);
  }

  create(order: any){
    return this.http.post(`${API_BASE}/api/orders`, order);
  }

  update(orderId: number, order: any){
    return this.http.put(`${API_BASE}/api/orders/${orderId}`, order);
  }

  delete(orderId: number){
    return this.http.delete(`${API_BASE}/api/orders/${orderId}`);
  }

  updateStatus(orderId: number, status: string){
    return this.http.patch(`${API_BASE}/api/orders/${orderId}/status`, { status });
  }
}
